#include <Servo.h>

// Pinos dos Olhos (Sensor Ultrassônico)
#define PIN_TRIG 12
#define PIN_ECHO 11

// Pinos dos Mecanismos da Caçamba
#define PIN_SERVO_BRACO 9
#define PIN_SERVO_CACAMBA 10

// Pinos das Rodas (Tração)
#define PIN_RODA_ESQ 5
#define PIN_RODA_DIR 6

// Pinos de Alerta: LED e Buzzer (MUDADO PARA D13)
#define PIN_LED_ALERTA 4
#define PIN_BUZZER 13

// Instanciação de todos os Servos do Trator
Servo servoBraco;
Servo servoCacamba;
Servo rodaEsq;
Servo rodaDir;

enum EstadosTrator {
  BUSCANDO,
  CARREGANDO,
  TRANSPORTANDO,
  OBSTACULO_DETECTADO
};

EstadosTrator estadoAtual = BUSCANDO;
unsigned long tempoEstado = 0;

long lerDistancia();
void pararRodas();
void andarParaFrente();
void andarDevagar();
void andarParaTras();
void girarParaDesviar();
void sinalizarEmergencia(int bipes);

void setup() {
  Serial.begin(9600);
  
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED_ALERTA, OUTPUT); 
  pinMode(PIN_BUZZER, OUTPUT);     
  
  servoBraco.attach(PIN_SERVO_BRACO);
  servoCacamba.attach(PIN_SERVO_CACAMBA);
  rodaEsq.attach(PIN_RODA_ESQ);
  rodaDir.attach(PIN_RODA_DIR);
  
  servoBraco.write(0);
  servoCacamba.write(0);
  digitalWrite(PIN_LED_ALERTA, LOW); 
  digitalWrite(PIN_BUZZER, LOW); 
  pararRodas();
  
  Serial.println("--- Trator Iniciado com Bipes Manuais Estáveis! ---");
  tempoEstado = millis();
}

void loop() {
  long distancia = lerDistancia();
  
  if (distancia > 0 && distancia < 20 && estadoAtual != CARREGANDO && estadoAtual != OBSTACULO_DETECTADO) {
    estadoAtual = OBSTACULO_DETECTADO;
    tempoEstado = millis();
  }

  switch (estadoAtual) {
    
    case BUSCANDO:
      Serial.println("Estado: Buscando... Andando para frente.");
      digitalWrite(PIN_LED_ALERTA, LOW); 
      digitalWrite(PIN_BUZZER, LOW);
      andarParaFrente();
      servoBraco.write(0);    
      servoCacamba.write(0);
      
      if (millis() - tempoEstado > 4000) {
        estadoAtual = CARREGANDO;
        tempoEstado = millis();
      }
      break;

    case CARREGANDO:
      Serial.println("Estado: Carregando! Movendo mecanismos.");
      andarDevagar(); 
      servoBraco.write(45);   
      servoCacamba.write(30); 
      delay(1500); 
      estadoAtual = TRANSPORTANDO;
      tempoEstado = millis();
      break;

    case TRANSPORTANDO:
      Serial.println("Estado: Transportando carga.");
      andarParaFrente();
      if (millis() - tempoEstado > 4000) {
        Serial.println("Estado: Descarregando!");
        pararRodas();
        servoBraco.write(60);   
        servoCacamba.write(0);  
        delay(2000);
        estadoAtual = BUSCANDO;
        tempoEstado = millis();
      }
      break;

    case OBSTACULO_DETECTADO:
      Serial.print("ALERTA: Obstáculo detectado a ");
      Serial.print(distancia);
      Serial.println("cm!");
      
      pararRodas();
      delay(200); 
      andarParaTras();
      
      sinalizarEmergencia(4); // Executa os bipes manuais livres de conflito
      
      girarParaDesviar();
      delay(1000);
      
      digitalWrite(PIN_LED_ALERTA, LOW); 
      digitalWrite(PIN_BUZZER, LOW);
      estadoAtual = BUSCANDO; 
      tempoEstado = millis();
      break;
  }
  delay(30);
}

// --- Nova Função União com Ondas Geradas Manualmente ---
void sinalizarEmergencia(int bipes) {
  for (int i = 0; i < bipes; i++) {
    digitalWrite(PIN_LED_ALERTA, HIGH); // Liga Luz
    
    // Gera uma onda quadrada manual para forçar o Wokwi a apitar
    unsigned long tempoInicioBipe = millis();
    while (millis() - tempoInicioBipe < 250) {
      digitalWrite(PIN_BUZZER, HIGH);
      delayMicroseconds(500); // Frequência do som
      digitalWrite(PIN_BUZZER, LOW);
      delayMicroseconds(500);
    }
    
    digitalWrite(PIN_LED_ALERTA, LOW);  // Desliga Luz
    digitalWrite(PIN_BUZZER, LOW);      // Garante silêncio
    delay(250);
  }
}

void andarParaFrente() { rodaEsq.write(180); rodaDir.write(0); }
void andarDevagar() { rodaEsq.write(120); rodaDir.write(60); }
void andarParaTras() { rodaEsq.write(0); rodaDir.write(180); }
void girarParaDesviar() { rodaEsq.write(180); rodaDir.write(180); }
void pararRodas() { rodaEsq.write(90);  rodaDir.write(90); }

long lerDistancia() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(5);
  digitalWrite(PIN_TRIG, LOW);
  long duracao = pulseIn(PIN_ECHO, HIGH, 15000); 
  if (duracao == 0) return 999;
  return duracao * 0.034 / 2;
}