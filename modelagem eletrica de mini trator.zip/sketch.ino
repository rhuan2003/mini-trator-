#include <Servo.h>

// Pinos dos Olhos (Sensor Ultrassônico)
#define PIN_TRIG 12
#define PIN_ECHO 11

// Pinos dos Mecanismos da Caçamba
#define PIN_SERVO_BRACO 9
#define PIN_SERVO_CACAMBA 10

// Pinos das Rodas (Tração)
#define PIN_RODA_ESQ 5
#define PIN_RODA_DIR 6

// Pinos de Alerta: LED e Buzzer (Novo!)
#define PIN_LED_ALERTA 4
#define PIN_BUZZER 3

// Instanciação de todos os Servos do Trator
Servo servoBraco;
Servo servoCacamba;
Servo rodaEsq;
Servo rodaDir;

// Estados operacionais da Rede de Petri
enum EstadosTrator {
  BUSCANDO,
  CARREGANDO,
  TRANSPORTANDO,
  OBSTACULO_DETECTADO
};

EstadosTrator estadoAtual = BUSCANDO;
unsigned long tempoEstado = 0;

void setup() {
  Serial.begin(9600);
  
  // Configuração dos pinos dos sensores e atuadores de efeito
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED_ALERTA, OUTPUT); 
  pinMode(PIN_BUZZER, OUTPUT);     // Configura pino do Buzzer
  
  // Inicialização de todos os servos
  servoBraco.attach(PIN_SERVO_BRACO);
  servoCacamba.attach(PIN_SERVO_CACAMBA);
  rodaEsq.attach(PIN_RODA_ESQ);
  rodaDir.attach(PIN_RODA_DIR);
  
  // Estado inicial físico de segurança
  servoBraco.write(0);
  servoCacamba.write(0);
  digitalWrite(PIN_LED_ALERTA, LOW); 
  digitalWrite(PIN_BUZZER, LOW); 
  pararRodas();
  
  Serial.println("--- Trator Completo com Som e Luz Inicializado! ---");
  tempoEstado = millis();
}

void loop() {
  // Medição constante da distância com os "olhos" do robô
  long distancia = lerDistancia();
  
  // Se detectar barreira a menos de 20cm, ativa a rotina de desvio
  if (distancia > 0 && distancia < 20 && estadoAtual != CARREGANDO && estadoAtual != OBSTACULO_DETECTADO) {
    estadoAtual = OBSTACULO_DETECTADO;
    tempoEstado = millis();
  }

  // Execução da máquina de estados (Rede de Petri)
  switch (estadoAtual) {
    
    case BUSCANDO:
      Serial.println("Estado: Buscando... Andando para frente.");
      digitalWrite(PIN_LED_ALERTA, LOW); 
      digitalWrite(PIN_BUZZER, LOW);
      andarParaFrente();
      servoBraco.write(0);    
      servoCacamba.write(0);
      
      if (millis() - tempoEstado > 4000) {
        estadoAtual = CARREGANDO;
        tempoEstado = millis();
      }
      break;

    case CARREGANDO:
      Serial.println("Estado: Carregando! Movendo mecanismos.");
      andarDevagar(); 
      
      servoBraco.write(45);   
      servoCacamba.write(30); 
      delay(1500); 
      
      estadoAtual = TRANSPORTANDO;
      tempoEstado = millis();
      break;

    case TRANSPORTANDO:
      Serial.println("Estado: Transportando carga.");
      andarParaFrente();
      
      if (millis() - tempoEstado > 4000) {
        Serial.println("Estado: Descarregando!");
        pararRodas();
        servoBraco.write(60);   
        servoCacamba.write(0);  
        delay(2000);
        
        estadoAtual = BUSCANDO;
        tempoEstado = millis();
      }
      break;

    case OBSTACULO_DETECTADO:
      Serial.print("ALERTA: Obstáculo detectado a ");
      Serial.print(distancia);
      Serial.println("cm! Dando Ré com Alerta Sonoro e Visual...");
      
      pararRodas();
      delay(500); 
      
      // Ativa motores para trás
      andarParaTras();
      // Executa os bipes sonoros e visuais sincronizados
      sinalizarEmergencia(4); 
      
      // Manobra o chassi para o lado livre
      girarParaDesviar();
      delay(1000);
      
      // Desliga todos os alertas ao retornar à segurança
      digitalWrite(PIN_LED_ALERTA, LOW); 
      digitalWrite(PIN_BUZZER, LOW);
      estadoAtual = BUSCANDO; 
      tempoEstado = millis();
      break;
  }
  delay(100);
}

// --- Função União: Piscar LED e Apitar Buzzer em Sincronia ---
void sinalizarEmergencia(int bipes) {
  for (int i = 0; i < bipes; i++) {
    digitalWrite(PIN_LED_ALERTA, HIGH); // Liga Luz
    digitalWrite(PIN_BUZZER, HIGH);     // Emite Som (Bipe agudo)
    delay(250);
    
    digitalWrite(PIN_LED_ALERTA, LOW);  // Desliga Luz
    digitalWrite(PIN_BUZZER, LOW);      // Corta Som
    delay(250);
  }
}

// --- Funções de Controle dos Servos de Rotação Contínua ---
void andarParaFrente() {
  rodaEsq.write(180); 
  rodaDir.write(0);   
}

void andarDevagar() {
  rodaEsq.write(120); 
  rodaDir.write(60);   
}

void andarParaTras() {
  rodaEsq.write(0); 
  rodaDir.write(180); 
}

void girarParaDesviar() {
  rodaEsq.write(180); 
  rodaDir.write(180); 
}

void pararRodas() {
  rodaEsq.write(90);  
  rodaDir.write(90);  
}

// --- Função do Sensor Ultrassônico ---
long lerDistancia() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long duracao = pulseIn(PIN_ECHO, HIGH, 30000);
  return duracao * 0.034 / 2;
}